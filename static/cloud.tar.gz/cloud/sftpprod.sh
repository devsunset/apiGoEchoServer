sftp -i ./key/ssh-key-2021-02-23.key  ubuntu@193.123.252.22
